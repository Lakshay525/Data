import streamlit as st
import pandas as pd
import streamlit.components.v1 as components

# --- 1. Page Configuration ---
st.set_page_config(page_title="Delhivery Network Intelligence", layout="wide", initial_sidebar_state="expanded")

st.title("Delhivery Network Intelligence Command Center")
st.markdown("Real-time network delay risk scores and route optimization engine.")

# --- 2. Load Data ---
@st.cache_data
def load_data():
    try:
        # Now loading the updated CSV with human-readable names
        df = pd.read_csv("network_route_strategy_named.csv")
        return df
    except FileNotFoundError:
        st.error("Error: 'network_route_strategy_named.csv' not found. Please run the mapping script first.")
        return pd.DataFrame()

df = load_data()

if not df.empty:
    # --- 3. Sidebar Configuration ---
    st.sidebar.header("Dispatch Simulator")
    st.sidebar.markdown("Test a corridor to see real-time SLA risk.")
    
    source_hubs = sorted(df['source_name'].unique())
    selected_source = st.sidebar.selectbox("Select Origin Hub", source_hubs)
    
    # Filter valid destinations based on the selected origin name
    valid_dests = sorted(df[df['source_name'] == selected_source]['destination_name'].unique())
    selected_dest = st.sidebar.selectbox("Select Destination Hub", valid_dests)
    
    times = df['time_of_day'].unique()
    selected_time = st.sidebar.selectbox("Select Time of Day", times)
    
    # --- 4. Main Dashboard: The Dispatch Simulator ---
    st.subheader(f"Route Analysis: {selected_source} -> {selected_dest}")
    
    # Filter data using the names
    route_data = df[(df['source_name'] == selected_source) & 
                    (df['destination_name'] == selected_dest) & 
                    (df['time_of_day'] == selected_time)]
    
    if not route_data.empty:
        route_info = route_data.iloc[0]
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(label="OSRM Distance", value=f"{route_info['osrm_distance']} km")
        with col2:
            st.metric(label="Carting Risk (>20% Delay)", value=f"{route_info['carting_risk_pct']}%")
        with col3:
            st.metric(label="FTL Risk (>20% Delay)", value=f"{route_info['ftl_risk_pct']}%")
        with col4:
            if route_info['recommended_route'] == 'FTL':
                st.success(f"Recommended: {route_info['recommended_route']}")
            else:
                st.info(f"Recommended: {route_info['recommended_route']}")
    else:
        st.warning("No historical data available for this specific corridor and time combination.")

    st.markdown("---")

    # --- 5. Network Overview & Visuals ---
    colA, colB = st.columns([1, 1])

    with colA:
        st.subheader("Top 10 Riskiest Corridors Right Now")
        st.markdown(f"Currently filtering for: **{selected_time}**")
        
        # Sort by riskiest Carting routes
        riskiest = df[df['time_of_day'] == selected_time].sort_values(by='carting_risk_pct', ascending=False).head(10)
        
        # Display the table using human-readable names
        display_df = riskiest[['source_name', 'destination_name', 'carting_risk_pct', 'recommended_route']]
        display_df.columns = ['Origin Hub', 'Destination Hub', 'SLA Risk %', 'Action']
        
        st.dataframe(display_df, use_container_width=True, hide_index=True)

    with colB:
        st.subheader("Network Bottleneck Map")
        st.markdown("Interactive view of network choke points (Red = High SLA Breach Contribution).")
        
        try:
            with open("bottleneck_network.html", "r", encoding='utf-8') as f:
                html_map = f.read()
            components.html(html_map, height=500)
        except FileNotFoundError:
            st.info("Interactive map not found. Run Phase 2 to generate 'bottleneck_network.html'.")